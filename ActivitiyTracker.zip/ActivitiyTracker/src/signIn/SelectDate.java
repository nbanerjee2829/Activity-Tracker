package signIn;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Panel;
import java.awt.Button;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;
import java.awt.List;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.UIManager;
import java.awt.Scrollbar;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JDesktopPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.DefaultComboBoxModel;
import java.awt.Toolkit;

//This class takes the date info from the user to display the stats according to date
public class SelectDate extends JFrame {
	
	//Declaring variables
    private User current;
    private JPanel contentPane;
    private Manager manager;
    private JPanel panel_1;
    private JLabel lblEmail;
    private JTextArea textArea;
    private ArrayList<Statistics> stats;
    private JTextField minDate;
    private JTextField minYear;
    private JTextField maxYear;
    private JTextField maxDate;
    private String minMonthVal;
    private String maxMonthVal;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SelectDate frame = new SelectDate();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    
    
    public SelectDate() throws IOException{
        setResizable(false);
        setIconImage(Toolkit.getDefaultToolkit().getImage(SelectDate.class.getResource("/images/logo4.PNG")));
        manager = Home.getManager();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 300, 400);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        //Creating a array which contains the months
        String[] months = {"jan","feb","mar","apr","may","jun","jul","aug","sept","oct","nov","dec"};
        
        //Combo box to input min month
        JComboBox minMnth = new JComboBox();
        minMnth.setBounds(80, 113, 84, 22);
        for (String i : months) {
            minMnth.addItem(i);
        }
        contentPane.add(minMnth);
        
        //Combo box to input max month
        JComboBox maxMnth = new JComboBox();
        maxMnth.setBounds(80, 210, 84, 22);
        for (String i : months) {
            minMnth.addItem(i);
        }
        contentPane.add(maxMnth);
        
        JLabel lblSelectDate = new JLabel("Select Date");
        lblSelectDate.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblSelectDate.setBounds(82, 13, 143, 29);
        contentPane.add(lblSelectDate);
        
        JLabel minDateLabel = new JLabel("From Date");
        minDateLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        minDateLabel.setBounds(12, 71, 143, 29);
        contentPane.add(minDateLabel);
        
        JLabel maxDateLabel = new JLabel("To Date");
        maxDateLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        maxDateLabel.setBounds(12, 168, 143, 29);
        contentPane.add(maxDateLabel);
        
        
        //TextFields
        minDate = new JTextField();
        minDate.setBounds(12, 113, 56, 22);
        contentPane.add(minDate);
        minDate.setColumns(10);
        
        minYear = new JTextField();
        minYear.setColumns(10);
        minYear.setBounds(177, 113, 105, 22);
        contentPane.add(minYear);
        
        maxYear = new JTextField();
        maxYear.setColumns(10);
        maxYear.setBounds(176, 210, 105, 22);
        contentPane.add(maxYear);
        
        maxDate = new JTextField();
        maxDate.setColumns(10);
        maxDate.setBounds(12, 210, 56, 22);
        contentPane.add(maxDate);
        
        //Action listener for the Done button
        JButton donebtn = new JButton("Done");

        donebtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] Data = new String[6];
                
                //Getting the inputted data from the user
                Data[0] = minDate.getText().toString();
                Data[1] = minMnth.getSelectedItem().toString();
                Data[2] = minYear.getText().toString();
                Data[3] = maxDate.getText().toString();
                Data[4] = maxMnth.getSelectedItem().toString();
                Data[5] = maxYear.getText().toString();
                Home.getProfile().setData(Data);
                setVisible(false);
            }
        });
        donebtn.setBounds(104, 261, 97, 25);
        contentPane.add(donebtn);
    }
    
    //This method returns the data inputted by the user
    public String[] getData() {
        String[] Data = new String[6];

        return Data;
    }
}
